Graphics3D 800,600,32,2
SetBuffer BackBuffer()

AmbientLight 255,255,255

Const Scale#=2.0

Include "Math.bb"
Include "Player.bb"

LoadStepSounds()

Const PLR_COL=1
Const WALL_COL=2

collider=CreateSphere()
ScaleEntity collider,Scale,Scale,Scale
PositionEntity collider,0,7,0
EntityType collider,PLR_COL

camera=CreateCamera()
CameraViewport camera,0,0,800,600

light=CreateLight()

room=LoadMesh("GFX/room.b3d")
roomTexture=LoadTexture("GFX/room.png")
EntityColor room,255,255,255
EntityType room,WALL_COL
EntityTexture room,roomTexture

Collisions PLR_COL,WALL_COL,2,2

Global frameTimer=CreateTimer(60)

oldTime=MilliSecs()

Global focused%=1

HidePointer

While Not KeyHit(1)
	If focused=1 Then
		If KeyHit(15)
			ShowPointer
			focused=0
		EndIf
	
		MoveMouse GraphicsWidth()/2,GraphicsHeight()/2	
	Else
		If MouseDown(1) Or KeyHit(15) Then
			HidePointer
			focused=1
		EndIf
	EndIf
	
	WaitTimer(frameTimer)
	
	MovePlayer(collider,camera,focused)
	
	UpdateWorld
			
	MoveCamera(collider,camera,focused)
	MoveEntity camera,0,0,-1
			
	RenderWorld
	
	Text 0,0,"FPS: "+1000/Max((MilliSecs()-oldTime),1)
	oldTime=MilliSecs()

	Flip
Wend

End