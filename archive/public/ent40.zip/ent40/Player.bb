Global CameraShake=0.0
Const CameraShakeAmount=4.0
Const RunMultiplier#=1.5
Const RunSpeedMultiplier#=1.8
Global StepNum=0
Global StepAgain=True
Global CameraPitch#=0.0

Dim FootstepSounds(7)

Function LoadStepSounds()
	For i=0 To 7
	    FootstepSounds(i)=LoadSound("SFX/Step"+(i+1)+".ogg")
	Next
End Function

Function FreeStepSounds()
	For i=0 To 7
	    FreeSound FootstepSounds(i)
	Next
End Function

Function MovePlayer(collider,camera,focused)
	Local dX=KeyDown(32)-KeyDown(30)
	Local dZ=KeyDown(17)-KeyDown(31)
	If KeyDown(42) Then
		dX=dX*RunSpeedMultiplier
		dZ=dZ*RunSpeedMultiplier
	EndIf
	If (Not dX=0) Or (Not dZ=0) Then
		Local ShakeAmount=CameraShakeAmount
		If KeyDown(42) Then
			ShakeAmount=ShakeAmount*RunMultiplier
		EndIf
		CameraShake=CameraShake+ShakeAmount
	EndIf
	If Sin(CameraShake*2) < -0.9 And StepAgain=True Then
		PlayStep()
		StepAgain=False
	EndIf
	If Sin(CameraShake*2) > 0.9 Then
		StepAgain=True
	EndIf
	If CameraShake>360 Then CameraShake=CameraShake-360
	MoveEntity collider,dX*0.1*Scale,0,dZ*0.1*Scale
	TurnEntity collider,0,0-MouseXSpeed()*focused,0
End Function

Function MoveCamera(collider,camera,focused)
	PositionEntity camera,EntityX(collider),EntityY(collider)+.8+Sin(CameraShake*2)/5,EntityZ(collider)
	RotateEntity camera,0,EntityYaw(collider),0
	TurnEntity camera,0,0,Sin(CameraShake)*1.25
	CameraPitch=CameraPitch+MouseYSpeed()*focused
	If CameraPitch>90 Then
		CameraPitch=90
	ElseIf CameraPitch<-90 Then
		CameraPitch=-90
	EndIf
	TurnEntity camera,CameraPitch,0,0
End Function

Function PlayStep()
	PlaySound(FootstepSounds(StepNum))
	StepNum=StepNum+1
	If StepNum=8 Then
		StepNum=0
	EndIf
End Function