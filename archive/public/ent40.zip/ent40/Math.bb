Function Max(a,b)
	If a>b Then
		Return a
	Else
		Return b
	EndIf
End Function 

Function Min(a,b)
	If a<b Then
		Return a
	Else
		Return b
	EndIf
End Function 